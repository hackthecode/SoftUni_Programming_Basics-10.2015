﻿using System;

namespace _07.QuotesInStrings
{
    class QuotesInStrings
    {
        static void Main()
        {
            string firstString = "The \"use\" of quotations causes difficulties.";
            string secondString = @"The ""use"" of quotations causes difficulties.";

            Console.WriteLine(firstString);
            Console.WriteLine(secondString);
        }
    }
}
