﻿using System;
using System.Text;

namespace _08.IsoscelesTriangle
{
    class IsoscelesTriangle
    {
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            // First Variant
            char copyright = '\u00A9'; // Copyright symbols © -  169 decimal / A9 hexadecimal
            Console.WriteLine(String.Format("{0,4}", copyright));
            Console.WriteLine(String.Format("{0,3}{1,2}", copyright, copyright));
            Console.WriteLine(String.Format("{0,2}{1,4}", copyright, copyright));
            Console.WriteLine(String.Format("{0}{1,2}{2,2}{3,2}", copyright, copyright, copyright, copyright));

            //Second Variant
            //int copyright = 169;    // Copyright symbols © -  169 decimal / A9 hexadecimal
            //Console.WriteLine(" " + " " + " " + (char)copyright);
            //Console.WriteLine(" " + " " + (char)copyright + " " + (char)copyright);
            //Console.WriteLine(" " + (char)copyright + " " + " " + " " + (char)copyright);
            //Console.WriteLine((char)copyright + " " + (char)copyright + " " + (char)copyright + " " + (char)copyright);
        }
    }
}