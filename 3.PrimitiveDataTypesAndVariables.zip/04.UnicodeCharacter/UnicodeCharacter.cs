﻿using System;
using System.Text;

namespace _04.UnicodeCharacter
{
    class UnicodeCharacter
    {
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            //First Variant
            char asteriskChar = '\u002A'; // char symbol * 42 decimal = 2A hex
            Console.WriteLine(asteriskChar);
            //Second Variant
            //int asteriskChar = 42; // char symbol * 42 decimal = 2A hex
            //Console.WriteLine((char)asteriskChar);
        }
    }
}
