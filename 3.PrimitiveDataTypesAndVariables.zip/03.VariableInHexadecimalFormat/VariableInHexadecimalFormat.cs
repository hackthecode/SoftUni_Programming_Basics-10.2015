﻿using System;

namespace _03.VariableInHexadecimalFormat
{
    class VariableInHexadecimalFormat
    {
        static void Main()
        {
            // (FE)16 = (254)10
            int hexValue = 0xFE;
            Console.WriteLine(hexValue);
        }
    }
}
