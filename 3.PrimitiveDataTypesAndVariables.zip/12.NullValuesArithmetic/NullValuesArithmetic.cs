﻿using System;

namespace _12.NullValuesArithmetic
{
    class NullValuesArithmetic
    {
        static void Main()
        {
            // Integer
            int? someInteger = null;
            Console.WriteLine("Integer with value null: {0}", someInteger);
            someInteger = 5;
            Console.WriteLine("Integer with value 5: {0}", someInteger);

            // Floating-point
            double? someDouble = null;
            Console.WriteLine("Double with value null: {0}", someDouble);
            someDouble = 2.5;
            Console.WriteLine("Double with value 2.5: {0}", someDouble);
        }
    }
}
