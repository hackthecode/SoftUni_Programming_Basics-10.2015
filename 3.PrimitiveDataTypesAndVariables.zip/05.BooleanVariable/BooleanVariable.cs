﻿using System;
using System.Text;

namespace _05.BooleanVariable
{
    class BooleanVariable
    {
        static void Main()
        {
            bool isFemale = false;
            Console.WriteLine(isFemale);
        }
    }
}
